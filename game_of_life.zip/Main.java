

public class Main{
    public  static void main(String[] args) {
        Cell run = new Cell();
        run.run();
    }
}