
// Neighbors class detemines whether the cell survie or dead on the next generation

public class Neighbors {
	
    public int getLivingNeighbor(char [][] g, int rows, int cols){
        // check all the surroundings of live cell
        int output = 0;

        //upperleft 
        if ((rows - 1 >= 0) && (cols - 1 >= 0)) {
			if (g[rows-1][cols - 1] == 'X') {
				output++; 
			}
		}
		// Check upper center 
		if ((rows - 1 >= 0) && (cols >= 0)) {
			if (g[rows-1][cols] == 'X') {
				output++; 
			}
		}
		// Check upper right 
		if ((rows - 1 >= 0) && (cols + 1 < 20)) {
			if (g[rows-1][cols+1] == 'X') {
				output++; 
			}
		}
		
		// Check center left 
		if ((rows >= 0) && (cols - 1 >= 0)) {
			if (g[rows][cols - 1] == 'X') {
				output++; 
			}
		}
		
		// Check center right 
		if ((rows >= 0) && (cols + 1 < 20)) {
			if (g[rows][cols+1] == 'X') {
				output++; 
			}
		}
		
		// Check lower left
		if ((rows + 1 < 20) && (cols - 1 >= 0)) {
			if (g[rows+1][cols - 1] == 'X') {
				output++; 
			}
		}
		// Check lower center 
		if ((rows + 1 < 20) && (cols >= 0)) {
			if (g[rows+1][cols] == 'X') {
				output++; 
			}
		}
		// Check lower right 
		if ((rows + 1 < 20) && (cols + 1 < 20)) {
			if (g[rows+1][cols+1] == 'X') {
				output++; 
			}
		}

        
    return output;
}

}
